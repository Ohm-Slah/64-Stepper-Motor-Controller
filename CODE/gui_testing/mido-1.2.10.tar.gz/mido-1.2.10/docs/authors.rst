Authors
=======

Ole Martin Bjørndalen (lead programmer) and many other contributors.

Many people have contributed to Mido over the years, but this page has
not been updated to include them. The :doc:`/changes` page
includes names of all contributors.
