Acknowledgments
===============

Thanks to /u/tialpoy/ on Reddit for extensive code review and helpful
suggestions.

Thanks to everyone who has sent bug reports and patches.

The PortMidi wrapper is based on portmidizero by Grant Yoshida.
